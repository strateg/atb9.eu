import{l as s,a}from"../chunks/Dfq9-KIm.js";export{s as load_css,a as start};

import{l as s,a}from"../chunks/PyWEOmK5.js";export{s as load_css,a as start};

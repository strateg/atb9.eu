import{l as s,a}from"../chunks/VrwxK3SD.js";export{s as load_css,a as start};

import{l as s,a}from"../chunks/sC8BpN-x.js";export{s as load_css,a as start};

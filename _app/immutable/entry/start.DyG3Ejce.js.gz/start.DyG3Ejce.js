import{l as s,a}from"../chunks/D-5KpcNr.js";export{s as load_css,a as start};

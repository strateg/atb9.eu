import{l as s,a}from"../chunks/BO7-sDYk.js";export{s as load_css,a as start};

import{l as s,a}from"../chunks/BM3CHPph.js";export{s as load_css,a as start};

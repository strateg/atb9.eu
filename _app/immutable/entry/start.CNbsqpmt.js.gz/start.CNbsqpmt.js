import{l as s,a}from"../chunks/C7hph3lE.js";export{s as load_css,a as start};

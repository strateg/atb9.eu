import{l as s,a}from"../chunks/DgJ0ZOyM.js";export{s as load_css,a as start};

import{l as s,a}from"../chunks/D9f5zEUU.js";export{s as load_css,a as start};

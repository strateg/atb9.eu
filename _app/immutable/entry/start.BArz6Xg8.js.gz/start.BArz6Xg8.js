import{l as s,a}from"../chunks/CFlF9Sat.js";export{s as load_css,a as start};

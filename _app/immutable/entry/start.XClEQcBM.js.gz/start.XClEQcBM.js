import{l as s,a}from"../chunks/DF7zsVVg.js";export{s as load_css,a as start};
